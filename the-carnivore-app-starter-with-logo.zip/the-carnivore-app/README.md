# The Carnivore — ordering website

A mobile-friendly pickup ordering website with a persistent SQLite menu/order database and a basic admin dashboard.

## Features
- Customer menu with the eight categories and illustrative INR prices.
- Cart totals calculated again on the server.
- Pickup-only order submission.
- UPI or cash selected as a payment preference.
- Admin login, order list/status updates, menu item add/edit/remove.
- SQLite persistence in `data/carnivore.sqlite`.

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set a long random `SESSION_SECRET`, a strong `ADMIN_PASSWORD`, and your actual `UPI_ID`.
4. Run `npm install`, then `npm start`.
5. Open `http://localhost:3000`.

## Before public deployment
- Use HTTPS and a hosting provider with persistent disk storage. If your host has ephemeral storage, move SQLite to a managed database or mount a persistent volume.
- Replace the default session store with a persistent production session store (the built-in Express MemoryStore is not suitable for production).
- Use a strong unique session secret and admin password; keep `.env` out of source control.
- Add backups, monitoring, privacy notice, and an order retention policy.
- Configure admin authentication with a production-grade identity provider or robust password hashing/rotation. Restrict admin access as appropriate.
- Set your verified UPI ID. This starter records the selected payment method but **does not process or verify UPI payments**. For real digital payments, integrate an Indian payment gateway server-side and verify signed webhooks before marking an order paid.
- Orders are stored and visible in the admin dashboard, but this starter does not send WhatsApp/SMS/email alerts. Add notifications if required.
- Confirm every menu item and price, tax treatment, food business details, and pickup workflow before launch.

## Deployment
Deploy as a Node.js web service on a host that supports Node 20 and persistent storage. Set environment variables from `.env.example` in the host dashboard; do not upload `.env`. Set `NODE_ENV=production`, use HTTPS, and attach a persistent volume for the `data` directory. Run `npm start`.

This is a starter project, not a payment-certified or audited production system.

## Brand logo
The uploaded The Carnivore logo is included at `public/assets/the-carnivore-logo.jpg` and displayed in the customer website header and as the site favicon. Replace this file with your updated logo (keeping the same filename) to change the branding.
