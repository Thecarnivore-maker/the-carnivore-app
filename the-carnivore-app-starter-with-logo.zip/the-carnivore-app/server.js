require("dotenv").config();
const express = require("express");
const session = require("express-session");
const rateLimit = require("express-rate-limit");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "carnivore.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS menu (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL,
  name TEXT NOT NULL,
  price INTEGER NOT NULL CHECK(price > 0),
  available INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  pickup_preference TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  note TEXT DEFAULT '',
  items_json TEXT NOT NULL,
  total INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'New',
  payment_status TEXT NOT NULL DEFAULT 'Unpaid',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
const categories = ["Barbeque","Fried Chicken","Fried Fish","Momo","Biryani","Kebab","Chowmin","Fried Rice"];
if (db.prepare("SELECT COUNT(*) AS n FROM menu").get().n === 0) {
  const seed = [
    ["Barbeque","Chicken BBQ (Half)",250],["Barbeque","Chicken BBQ (Full)",450],["Barbeque","Beef BBQ (Half)",350],["Barbeque","Beef BBQ (Full)",650],
    ["Fried Chicken","Classic Fried Chicken (2 pcs)",180],["Fried Chicken","Classic Fried Chicken (4 pcs)",320],["Fried Chicken","Spicy Fried Chicken (2 pcs)",200],["Fried Chicken","Spicy Fried Chicken (4 pcs)",360],
    ["Fried Fish","Fish Fry (Single)",220],["Fried Fish","Fish Fry (Double)",380],["Fried Fish","Fish Finger (6 pcs)",260],["Fried Fish","Fish Finger (12 pcs)",480],
    ["Momo","Veg Momo (6 pcs)",120],["Momo","Veg Momo (12 pcs)",220],["Momo","Chicken Momo (6 pcs)",150],["Momo","Chicken Momo (12 pcs)",280],
    ["Biryani","Veg Biryani",180],["Biryani","Chicken Biryani",250],["Biryani","Mutton Biryani",350],["Biryani","Special Carnivore Biryani",420],
    ["Kebab","Chicken Seekh Kebab (4 pcs)",220],["Kebab","Mutton Seekh Kebab (4 pcs)",320],["Kebab","Chicken Malai Kebab (4 pcs)",360],["Kebab","Mix Kebab Platter",420],
    ["Chowmin","Veg Chowmin",120],["Chowmin","Egg Chowmin",150],["Chowmin","Chicken Chowmin",180],["Chowmin","Mix Chowmin",220],
    ["Fried Rice","Veg Fried Rice",120],["Fried Rice","Egg Fried Rice",150],["Fried Rice","Chicken Fried Rice",180],["Fried Rice","Prawn Fried Rice",220]
  ];
  const ins = db.prepare("INSERT INTO menu(category,name,price) VALUES(?,?,?)");
  db.transaction(rows => rows.forEach(r => ins.run(...r)))(seed);
}
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: false, limit: "10kb" }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));
const orderLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false });
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: "draft-7", legacyHeaders: false });
function admin(req,res,next) { if (req.session && req.session.admin) return next(); return res.status(401).json({ error: "Admin login required" }); }
const money = n => Number.isInteger(n) && n > 0 && n <= 100000;

app.get("/api/config", (req,res) => res.json({ businessName: process.env.BUSINESS_NAME || "The Carnivore", upiConfigured: Boolean(process.env.UPI_ID) && !process.env.UPI_ID.startsWith("your-") }));
app.get("/api/menu", (req,res) => {
  const rows = db.prepare("SELECT id,category,name,price FROM menu WHERE available=1 ORDER BY id").all();
  res.json({ categories, items: rows });
});
app.post("/api/orders", orderLimiter, (req,res) => {
  const { customerName, phone, pickupPreference, paymentMethod, note, items } = req.body || {};
  if (typeof customerName !== "string" || customerName.trim().length < 2 || customerName.length > 80) return res.status(400).json({ error: "Enter your name." });
  if (typeof phone !== "string" || !/^[0-9+ ()-]{10,16}$/.test(phone.trim())) return res.status(400).json({ error: "Enter a valid phone number." });
  if (!["UPI","Cash"].includes(paymentMethod)) return res.status(400).json({ error: "Choose UPI or cash." });
  if (!["ASAP — confirm with restaurant","In 30 minutes — request","In 45 minutes — request","In 60 minutes — request"].includes(pickupPreference)) return res.status(400).json({ error: "Choose a pickup preference." });
  if (!Array.isArray(items) || !items.length || items.length > 40) return res.status(400).json({ error: "Your cart is empty or too large." });
  let total = 0; const cleanItems = [];
  for (const item of items) {
    const id = Number(item.id), quantity = Number(item.quantity);
    if (!Number.isInteger(id) || !Number.isInteger(quantity) || quantity < 1 || quantity > 30) return res.status(400).json({ error: "Invalid cart item." });
    const product = db.prepare("SELECT id,category,name,price FROM menu WHERE id=? AND available=1").get(id);
    if (!product) return res.status(400).json({ error: "A menu item is no longer available. Refresh the menu." });
    total += product.price * quantity;
    cleanItems.push({ ...product, quantity, lineTotal: product.price * quantity });
  }
  if (total > 300000) return res.status(400).json({ error: "Order total exceeds the limit." });
  const result = db.prepare(`INSERT INTO orders(customer_name,phone,pickup_preference,payment_method,note,items_json,total)
    VALUES(?,?,?,?,?,?,?)`).run(customerName.trim(), phone.trim(), pickupPreference, paymentMethod, String(note || "").slice(0,500), JSON.stringify(cleanItems), total);
  res.status(201).json({
    orderId: result.lastInsertRowid, total, paymentMethod,
    message: paymentMethod === "UPI" ? "Order received. Complete UPI payment only using the verified payment instructions provided by the restaurant, then wait for confirmation." : "Order received. Pay cash at pickup after the restaurant confirms."
  });
});
app.post("/api/admin/login", loginLimiter, async (req,res) => {
  const username = process.env.ADMIN_USERNAME || "admin";
  const password = process.env.ADMIN_PASSWORD || "";
  if (!password || password === "change-this-before-launch") return res.status(503).json({ error: "Set a secure ADMIN_PASSWORD in .env before enabling admin login." });
  if (req.body.username !== username || !await bcrypt.compare(String(req.body.password || ""), await bcrypt.hash(password, 10))) {
    // Constant-time-ish comparison; for production use a managed identity provider or stored password hash.
    return res.status(401).json({ error: "Incorrect username or password." });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start admin session." });
    req.session.admin = true;
    res.json({ ok: true });
  });
});
app.post("/api/admin/logout", admin, (req,res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/admin/me", (req,res) => res.json({ authenticated: Boolean(req.session && req.session.admin) }));
app.get("/api/admin/orders", admin, (req,res) => {
  const orders = db.prepare("SELECT * FROM orders ORDER BY id DESC LIMIT 200").all().map(o => ({...o, items: JSON.parse(o.items_json)}));
  res.json({ orders });
});
app.patch("/api/admin/orders/:id", admin, (req,res) => {
  const statuses = ["New","Accepted","Preparing","Ready for pickup","Completed","Cancelled"];
  const payStatuses = ["Unpaid","Payment reported","Paid","Refunded"];
  const { status, paymentStatus } = req.body || {};
  if (status && !statuses.includes(status)) return res.status(400).json({ error: "Invalid order status." });
  if (paymentStatus && !payStatuses.includes(paymentStatus)) return res.status(400).json({ error: "Invalid payment status." });
  const row = db.prepare("SELECT id FROM orders WHERE id=?").get(Number(req.params.id));
  if (!row) return res.status(404).json({ error: "Order not found." });
  if (status) db.prepare("UPDATE orders SET status=? WHERE id=?").run(status,row.id);
  if (paymentStatus) db.prepare("UPDATE orders SET payment_status=? WHERE id=?").run(paymentStatus,row.id);
  res.json({ ok: true });
});
app.post("/api/admin/menu", admin, (req,res) => {
  const { category, name, price } = req.body || {};
  if (!categories.includes(category) || typeof name !== "string" || name.trim().length < 2 || name.length > 100 || !money(Number(price))) return res.status(400).json({ error: "Check the category, name, and price." });
  const r = db.prepare("INSERT INTO menu(category,name,price) VALUES(?,?,?)").run(category,name.trim(),Number(price));
  res.status(201).json({ id:r.lastInsertRowid });
});
app.patch("/api/admin/menu/:id", admin, (req,res) => {
  const { name, price, available } = req.body || {};
  const row = db.prepare("SELECT id FROM menu WHERE id=?").get(Number(req.params.id));
  if (!row) return res.status(404).json({ error: "Menu item not found." });
  if (name !== undefined && (typeof name !== "string" || name.trim().length < 2 || name.length > 100)) return res.status(400).json({ error: "Invalid item name." });
  if (price !== undefined && !money(Number(price))) return res.status(400).json({ error: "Invalid price." });
  if (available !== undefined && typeof available !== "boolean") return res.status(400).json({ error: "Invalid availability." });
  if (name !== undefined) db.prepare("UPDATE menu SET name=? WHERE id=?").run(name.trim(),row.id);
  if (price !== undefined) db.prepare("UPDATE menu SET price=? WHERE id=?").run(Number(price),row.id);
  if (available !== undefined) db.prepare("UPDATE menu SET available=? WHERE id=?").run(available?1:0,row.id);
  res.json({ ok:true });
});
app.get("/health", (req,res) => res.json({ ok:true }));
app.listen(PORT, () => console.log(`The Carnivore is running on port ${PORT}`));
